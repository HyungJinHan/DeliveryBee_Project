import React from "react";

const MenuSandwich = () => {
  return <div>샌드위치</div>;
};

export default MenuSandwich;
