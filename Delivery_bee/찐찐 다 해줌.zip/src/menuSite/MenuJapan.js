import React from "react";

const MenuJapan = () => {
  return <div>일식</div>;
};

export default MenuJapan;
