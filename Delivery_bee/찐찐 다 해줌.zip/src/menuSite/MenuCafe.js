import React from "react";

const MenuCafe = () => {
  return <div>카페</div>;
};

export default MenuCafe;
