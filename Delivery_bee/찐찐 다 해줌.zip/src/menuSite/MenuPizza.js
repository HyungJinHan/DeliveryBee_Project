import React from "react";

const MenuPizza = () => {
  return <div>피자</div>;
};

export default MenuPizza;
