import React from "react";

const MenuBurger = () => {
  return <div>햄버거</div>;
};

export default MenuBurger;
