import React from "react";

const MenuKfood = () => {
  return <div>한식</div>;
};

export default MenuKfood;
