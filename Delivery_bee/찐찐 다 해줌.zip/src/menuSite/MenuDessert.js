import React from "react";

const MenuDessert = () => {
  return <div>디저트</div>;
};

export default MenuDessert;
