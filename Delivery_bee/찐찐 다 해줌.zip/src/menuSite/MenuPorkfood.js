import React from "react";

const MenuPorkfood = () => {
  return <div>족발</div>;
};

export default MenuPorkfood;
