import React from "react";

const MenuChina = () => {
  return <div>중식</div>;
};

export default MenuChina;
